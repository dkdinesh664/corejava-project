package miniproject;

import java.awt.Color;


import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



class mainScreen implements ActionListener{
	
	static JFrame frame;
	JButton button1;
	JButton button2;
	JPanel panel;
	JLabel label;
	ImageIcon icon;
	
	
	mainScreen(){
		
		frame = new JFrame("UNV Bank Of India ");
		panel=new JPanel() ; 
		label=new JLabel();
		icon=new ImageIcon("unv.png");
		button1=new JButton();
		button2=new JButton();
		
		
		button1.setBounds(200, 300, 150, 50);
		button1.setText("PRIVATE SECTION");
		button1.setFocusable(false);
		button1.addActionListener(this);
		
		button2.setBounds(700, 300, 150, 50);
		button2.setText("PUBLIC SECTION");
		button2.setFocusable(false);
		button2.addActionListener(this);
		
		label.setText("WELCOME TO UNV BANK OF INDIA");
		label.setIcon(icon);
		label.setBackground(Color.ORANGE);
		label.setOpaque(true);
		label.setBounds(300, 60, 500, 80);
		label.setIconTextGap(20);
		label.setFont(new Font("comic sans",Font.BOLD,20));
		
		
		
		
		panel.setBounds(90, 60,1100,500);
	//	panel.setPreferredSize(new Dimension(1100,500));
		panel.setLayout(null);
		panel.setBackground(Color.PINK);
		panel.add(label);
		panel.add(button1);
		panel.add(button2);
		
		frame.setSize(1400,700);		
	//frame.setLayout(new FlowLayout(FlowLayout.CENTER,0,60));
		frame.setLayout(null);
		frame.getContentPane().setBackground(Color.BLUE);
		frame.setVisible(true);
		frame.add(panel);
		
		
		
	}
public static void alert() {
	
	//JOptionPane.showInputDialog("Enter password");
	 String nm="dinesh1234";
	String[] response= {"retry again","thank you"};
	int retry=0;
	
	ImageIcon icon=new ImageIcon("unv.png");
	
	String name = JOptionPane.showInputDialog("Enter password");
	
	if(nm.contentEquals(name)) {
		JOptionPane.showMessageDialog(null, "welcome Dinesh",null,JOptionPane.PLAIN_MESSAGE );
		if(retry==0) {
			frame.dispose();
			new private_section();
		}
		
	}
	else {
		//JOptionPane.showMessageDialog(null, "password is incorrect","warning ",JOptionPane.ERROR_MESSAGE );
		int a=	JOptionPane.showOptionDialog(null, "password is incorrect", "WARNING MESSAGE",
			JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, icon, response, 0);
		if(retry==a) {
			
			mainScreen.alert();
			
		}

	}	
	
	
	
	
	
	
	
}


	public void actionPerformed(ActionEvent e) {
		JButton B = (JButton)e.getSource();
		
		if(B.getActionCommand().equals("PRIVATE SECTION"))
		{
			
			mainScreen.alert();
			
			} 
		else if(B.getActionCommand().equals("PUBLIC SECTION")){
			
		    new public_section().public_section_1();
			
			
		}
					
		}	
}

public class App 
{
    public static void main( String[] args )
    {
     new mainScreen();	
    	
    }
}
