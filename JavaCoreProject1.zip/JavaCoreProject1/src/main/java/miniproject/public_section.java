package miniproject;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;




public class public_section  implements ActionListener {

	
	 public static ArrayList<Customer> c1;
	 JLabel wid,Dep;
		JTextField twid,tDep;
		
		JFrame frame;
		JPanel panel,p1,p2;
//		JButton button1;
		JButton button2;
		JButton button3;
		JButton button4;
		JButton button5;
	
	
	
		String accno = JOptionPane.showInputDialog("ENTER ACCOUNT NO:");
		
	public  void public_section_1(){
		
		
		

		String colmn[] ={"Account No","Account Holder","Account Type","Balance"};
				
		String data[][] = new String[1][4];
		
	//	int retry=0;
		
	//	ImageIcon icon=new ImageIcon("unv.png");
	//	String[] response= {"retry again","thank you"};
	
	
		for(Customer c1 : register.CA){
		
			if (c1.getAccno() ==Integer.valueOf(accno))
			{
				
				data[0][0] = Integer.toString(c1.getAccno());
				data[0][1] = c1.getAccnm();
				data[0][2] = c1.getAcctype();
				data[0][3] = Long.toString(c1.getAmt());
				
				
				
				mainScreen.frame.dispose();
				
				frame = new JFrame(" PUBLIC SECTION ");
				panel=new JPanel() ; 
				
				JScrollPane jsp;
				JTable t;
				
				Font f2=new Font("TimesRoman",Font.BOLD,15);
				
				
				wid=new JLabel("ENTER AMOUNT TO WITHDRAW :");wid.setFont(f2);
				twid=new JTextField(15);
				
				Dep=new JLabel("ENTER AMOUNT TO DEPOSIT :");Dep.setFont(f2);
				tDep=new JTextField(15);
				
				
				p1=new JPanel(new GridBagLayout());
				p2=new JPanel(new GridBagLayout());
				GridBagConstraints c2=new GridBagConstraints();
				GridBagConstraints c3=new GridBagConstraints();
				                                                                //       column
				c2.insets=new Insets(0,20,0,0);                                //         0  1   2   
				c2.anchor=GridBagConstraints.LINE_START; 
				c3.insets=new Insets(0,20,0,0);                                //         0  1   2   
				c3.anchor=GridBagConstraints.LINE_START;  
				

				c2.gridx=0;c2.gridy=0;p1.add(wid,c2);                    
				c2.gridx=1;c2.gridy=0;p1.add(twid,c2);
				c3.gridx=0;c3.gridy=0;p2.add(Dep,c3);                    
				c3.gridx=1;c3.gridy=0;p2.add(tDep,c3);
				
				p1.setBounds(450, 260, 500, 50);
				p2.setBounds(450, 360, 500, 50);
				
				
				frame.add(p1);
				frame.add(p2);
				
			//	button1=new JButton();
				button2=new JButton();
				button3=new JButton();
				button4=new JButton();
				button5=new JButton();
		/*		
				button1.setBounds(200, 200, 150, 50);
				button1.setText("OPEN ACCOUNT");
				button1.setFocusable(false);
				button1.addActionListener(this);
		*/
		/*		
				button2.setBounds(700, 200, 150, 50);
				button2.setText("CHECK BALANCE");
				button2.setFocusable(false);
				button2.addActionListener(this);
				
		*/		
				button3.setBounds(200, 200, 150, 50);
				button3.setText("WITHDRAW");
				button3.setFocusable(false);
				button3.addActionListener(this);
				
				button4.setBounds(200, 300, 150, 50);
				button4.setText("DEPOSIT");
				button4.setFocusable(false);
				button4.addActionListener(this);
				

				button5.setBounds(200, 400, 150, 50);
				button5.setText("BACK");
				button5.setFocusable(false);
				button5.addActionListener(this);
				
				
				panel.setBounds(90, 60,1100,550);
			//	panel.setPreferredSize(new Dimension(1100,500));
				panel.setLayout(null);
				panel.setBackground(Color.PINK);
			//	panel.add(button1);
			//	panel.add(button2);
				panel.add(button3);
				panel.add(button4);
				panel.add(button5);
				
				
			

				
				
				frame.setLayout(null);
				frame.getContentPane().setBackground(Color.BLUE);
				frame.setVisible(true);
				frame.setSize(1400,700);
				
				
				
				
				
				
				t=new JTable(data,colmn);
				jsp=new JScrollPane(t); 
				jsp.setBounds(150,30,500,100);
				frame.add(panel);
				panel.add(jsp);
				
			 
				
				
				
				
		    }
			else {
	/*		int a=	JOptionPane.showOptionDialog(null, "Account No is incorrect", "WARNING MESSAGE",
					JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, icon, response, 0);
				if(retry==a) {
					this.frame.dispose();
					new mainScreen();
					
				
				}
			*/
		
			}
		
		
		}
		
			
		
		
		

			
	
	}	
	

	public void insertcustomer1() {
		
		for(Customer c1 : register.CA) {
			
			if (c1.getAccno() ==Integer.valueOf(accno)) {
				
				 if((Long.parseLong(twid.getText()) >=100 && Long.parseLong(twid.getText()) <=20000)
		 				 && ( (  c1.getAmt()> Long.parseLong(twid.getText())))) {
					 
					 
					 
					 c1.setAmt(c1.getAmt() -Long.parseLong(twid.getText()) );
					 
					 c1.setWidth(Long.parseLong(twid.getText()));
					 
				 	 twid.setText("");
		 		 	 JOptionPane.showMessageDialog(null, "AMOUNT WITHDRAWN ",null,JOptionPane.INFORMATION_MESSAGE ); 
					 
				 }
				 else {
					 
					 JOptionPane.showMessageDialog(null, "check your amount ",null,JOptionPane.INFORMATION_MESSAGE );
				 }
				
				
				
				
				
			}
			else {
				
				
				
			}
			
			
			
			
		}
		
		
	}
			

	public void insertcustomer2() {
		
		for(Customer c1 : register.CA) {
			
			if (c1.getAccno() ==Integer.valueOf(accno)) {
				
				 if(( Integer.parseInt(tDep.getText()) <=100000)) {
					 
					 
					 
					 c1.setAmt(c1.getAmt() +Long.parseLong(tDep.getText()) );
					 
					 c1.setDeposit(Long.parseLong(tDep.getText()));
					 
				 	 tDep.setText("");
		 		 	 JOptionPane.showMessageDialog(null, "AMOUNT DEPOSITED ",null,JOptionPane.INFORMATION_MESSAGE ); 
					 
				 }
				 else {
					 
					 JOptionPane.showMessageDialog(null, "check your amount ",null,JOptionPane.INFORMATION_MESSAGE );
				 }
				
				
				
				
				
			}
			else {
				
				
				
			}
			
			
			
			
		}
		
		
	}
		







	public static void main(String[] args) {
	
     
	}


	public void actionPerformed(ActionEvent e) {
		JButton B = (JButton)e.getSource();
		
		
		
        if(B.getActionCommand().equals("WITHDRAW")){
        	
   	
 		insertcustomer1();
 		
        }     	
        	
          //  new withdraw();
       else if(B.getActionCommand().equals("DEPOSIT")){
			
            insertcustomer2();
       }
       else if(B.getActionCommand().equals("BACK")){
			
    	  this.frame.dispose();
    	   new mainScreen();	
		}
		
	}








}
