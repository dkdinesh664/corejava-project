package miniproject;

public class Customer 
{
	private String accnm;
	private String dob;
	private String nat;
	private String gender;
	private String address;
	private  int accno;
	private String acctype;
	private String accem;
	private long mob;
	private  long amt;
    private  long width;
    private  long deposit;
	
	

	
	
	
	public String toString()
	{
		return getAccno()+"\t"+getAccnm()+"\t "+getDob()+"\t"+getNat()+"\t"+getGender()+"\t"+getAddress()+"\t"+getAcctype()+
				"\t"+getAccem()+"\t"+getMob()+"\t"+getAmt();
		
	}






	public String getAccnm() {
		return accnm;
	}






	public void setAccnm(String accnm) {
		this.accnm = accnm;
	}






	public String getDob() {
		return dob;
	}






	public void setDob(String dob) {
		this.dob = dob;
	}






	public String getGender() {
		return gender;
	}






	public void setGender(String gender) {
		this.gender = gender;
	}






	public String getNat() {
		return nat;
	}






	public void setNat(String nat) {
		this.nat = nat;
	}






	public String getAddress() {
		return address;
	}






	public void setAddress(String address) {
		this.address = address;
	}






	public  int getAccno() {
		return accno;
	}






	public void setAccno(int accno) {
		this.accno = accno;
	}






	public String getAcctype() {
		return acctype;
	}






	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}






	public String getAccem() {
		return accem;
	}






	public void setAccem(String accem) {
		this.accem = accem;
	}






	public long getMob() {
		return mob;
	}






	public void setMob(long mob) {
		this.mob = mob;
	}






	public long getDeposit() {
		return deposit;
	}






	public  void setDeposit(long deposit1) {
		this.deposit = deposit1;
	}






	public long getAmt() {
		return amt;
	}






	public void setAmt(long amt) {
		this.amt = amt;
	}






	public long getWidth() {
		return width;
	}






	public void setWidth(long width) {
		this.width = width;
	}











	
}
