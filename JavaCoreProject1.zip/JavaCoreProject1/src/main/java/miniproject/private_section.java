package miniproject;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class private_section implements ActionListener{

	JFrame frame;
	JPanel panel;
	JButton button1;
	JButton button2;
	JButton button3;
	ImageIcon icon;
	JLabel label;
	private_section(){
		
		frame = new JFrame(" PRIVATE SECTION ");
		label=new JLabel();
		panel=new JPanel() ; 
		button1=new JButton();
		button2=new JButton();
		button3=new JButton();
	
		
		icon=new ImageIcon("public section2.png");
		
		button1.setBounds(200, 250, 200, 50);
		button1.setText("OPEN ACCOUNT");
		button1.setFocusable(false);
		button1.addActionListener(this);
		
		button2.setBounds(700, 250, 200, 50);
		button2.setText("CHECK CUSTOMER DETAILS");
		button2.setFocusable(false);
		button2.addActionListener(this);
		
		
		button3.setBounds(480, 350, 150, 50);
		button3.setText("BACK");
		button3.setFocusable(false);
		button3.addActionListener(this);
		
		
		label.setText("PRIVATE SECTION");
		label.setIcon(icon);
		label.setBackground(Color.ORANGE);
		label.setOpaque(true);
		label.setBounds(300, 60, 450, 100);
		label.setIconTextGap(30);
		label.setFont(new Font("comic sans",Font.BOLD,20));
		
		
		
		panel.setBounds(90, 60,1100,500);
	//	panel.setPreferredSize(new Dimension(1100,500));
		panel.setLayout(null);
		panel.setBackground(Color.PINK);
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
	    panel.add(label);
		
		
	
		
		
		
		
		frame.setLayout(null);
		frame.getContentPane().setBackground(Color.BLUE);
		frame.setVisible(true);
		frame.setSize(1400,700);
		frame.add(panel);
		
		
		
		
		
	
		
		
		
		
		
		
		
	}
	
	
	public void actionPerformed(ActionEvent e) {
		
	JButton B = (JButton)e.getSource();
		
		if(B.getActionCommand().equals("OPEN ACCOUNT"))
		{
			this.frame.dispose();
			new register();
			
		} 
		else if(B.getActionCommand().equals("BACK")){
			this.frame.dispose();
			new mainScreen();
		}
       else if(B.getActionCommand().equals("CHECK CUSTOMER DETAILS")){
    	   this.frame.dispose();
    	  new AcHolder_detail();
		}
	
	}
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
         new private_section();
	}


}

	
	
	
	
	
	


