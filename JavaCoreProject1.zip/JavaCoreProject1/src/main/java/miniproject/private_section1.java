package miniproject;

import java.awt.Color;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class private_section1 {

      public static void main(String... g) {
    	 
    	  
      }
}
class register  implements ActionListener{
	  
	 public static ArrayList<Customer> CA;
	 JFrame frame;
	 JLabel reg;
	 JLabel name;
	 JLabel email;
	 JLabel phone;
	 JLabel gender;JLabel balance,dob,nat,add,accno,acctype;
	 JTextField tName,tEmail,tPhone,tBalance,tdob,tnat,tadd,taccno,tacctype;
	 JRadioButton male1,female1;
	 ButtonGroup bg;
	 JButton b1,b2;
	 JPanel p1,p2;

		static 
		{
			CA = new ArrayList<Customer>(); 
		}
	
	public  register() {
		
		
		frame=new JFrame("Account Opening Form");
		
		Font f1=new Font("TimesRoman",Font.BOLD,18);
		Font f2=new Font("TimesRoman",Font.BOLD,15);
		
		
		reg=new JLabel("ACCOUNT OPENING FORM:");reg.setFont(f1);
		name=new JLabel("Name");name.setFont(f2);
		email=new JLabel("Email");email.setFont(f2);
		phone=new JLabel("Phone No");phone.setFont(f2);
		gender=new JLabel("Gender");gender.setFont(f2);
		balance=new JLabel("Deposit");balance.setFont(f2);
		dob=new JLabel("Date of birth");dob.setFont(f2);
		nat=new JLabel("Nationality");nat.setFont(f2);
		add=new JLabel("Address");add.setFont(f2);
		accno=new JLabel("Account no");accno.setFont(f2);
		acctype=new JLabel("Account type");acctype.setFont(f2);
		
		
		tName=new JTextField(15);
		tEmail=new JTextField(15);
		tPhone = new JTextField(15);
		tBalance=new JTextField(15);
		tdob=new JTextField(15);
		tnat=new JTextField(15);
		tadd=new JTextField(15);
		taccno=new JTextField(15);
		tacctype=new JTextField(15);
		
		
		male1= new JRadioButton("male");
		female1=new JRadioButton("Female");
		
		
		bg=new ButtonGroup();
		bg.add(male1);
		bg.add(female1);
		
		
		b1 =new JButton("GENERATE ACCOUNT");b1.setFont(f2);
		b2=new JButton("BACK");b2.setFont(f2);
		
		p2=new JPanel();
		p2.add(male1);
		p2.add(female1);
		
		
		p1=new JPanel(new GridBagLayout());
		GridBagConstraints c1=new GridBagConstraints();
		                                                                //       column
		c1.insets=new Insets(10,20,30,10);                                //         0  1   2   
		c1.anchor=GridBagConstraints.LINE_START;  
	                                                                  //       0
		//c1.gridx=0;c1.gridy=0;p1.add(reg,c1);                      // row    1
		                                                            //         2
		
		
		c1.gridx=0;c1.gridy=0;p1.add(name,c1);                    
		c1.gridx=1;c1.gridy=0;p1.add(tName,c1);
		c1.gridx=0;c1.gridy=1;p1.add(dob,c1);
		c1.gridx=1;c1.gridy=1;p1.add(tdob,c1);
		c1.gridx=0;c1.gridy=2;p1.add(nat,c1);
		c1.gridx=1;c1.gridy=2;p1.add(tnat,c1);
		c1.gridx=0;c1.gridy=3;p1.add(gender,c1);
		c1.gridx=1;c1.gridy=3;p1.add(p2,c1);
		c1.gridx=0;c1.gridy=4;p1.add(add,c1);
		c1.gridx=1;c1.gridy=4;p1.add(tadd,c1);
		c1.gridx=2;c1.gridy=0;p1.add(accno,c1);
		c1.gridx=3;c1.gridy=0;p1.add(taccno,c1);
		c1.gridx=2;c1.gridy=1;p1.add(acctype,c1);
		c1.gridx=3;c1.gridy=1;p1.add(tacctype,c1);
		c1.gridx=2;c1.gridy=2;p1.add(email,c1);
		c1.gridx=3;c1.gridy=2;p1.add(tEmail,c1);
		
		c1.gridx=2;c1.gridy=3;p1.add(phone,c1);
		c1.gridx=3;c1.gridy=3;p1.add(tPhone,c1);
		
		c1.gridx=2;c1.gridy=4;p1.add(balance,c1);
		c1.gridx=3;c1.gridy=4;p1.add(tBalance,c1);
		
		c1.gridx=3;c1.gridy=6;p1.add(b1,c1);
		
		
		
		
		p1.setBackground(Color.CYAN);
     	p2.setBackground(Color.cyan);
		b1.setBackground(Color.PINK);
		reg.setForeground(Color.RED);
		
		p1.setBounds(40, 40, 700, 500);
		b2.setBounds(1000, 400, 100, 40);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
	
		
		//frame.getContentPane().add(p1);
		frame.add(p1);
		frame.add(b2);
		frame.setLayout(null);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.getContentPane().setBackground(Color.PINK);
		frame.setVisible(true);
		frame.setSize(1400,700);
	}
	public void insertcustomer(int acc_no,String nm,String d_o_b,String n_a_t,
			String gender1,String a_d_d,String acc_type,String acc_em,long m_o_b,long amt)
	{
		Customer c = new Customer();
	
		
		c.setAccno(acc_no);
		c.setAccnm(nm);
		c.setDob(d_o_b);
		c.setNat(n_a_t);
		c.setGender(gender1);
		c.setAddress(a_d_d);
		c.setAcctype(acc_type);
		c.setAccem(acc_em);
		c.setMob(m_o_b);
		c.setAmt(amt);
	
		
		
		
		
		
		CA.add(c);
		System.out.println(c);
	}

	public void actionPerformed(ActionEvent e) {
		

		JButton B = (JButton)e.getSource();
		
		
		if(B.getActionCommand().equals("GENERATE ACCOUNT"))
	//	if(e.getSource()==b1)
		{
			
			int acc_no;
			String nm;
			String d_o_b;
			String n_a_t;
			String gender1="male";
			String a_d_d;
			String acctype;
			String acc_em;
			long mob;
			long amt;
			
		//	long Deposit;
			
			// p = Integer.parseInt(tPhone.getText());
			
			acc_no=Integer.parseInt(taccno.getText());
			 nm = tName.getText();
			 d_o_b = tdob.getText();
			n_a_t=tnat.getText();
		 if(female1.isSelected()) {
			 gender1="female";
		 }
		 
		    a_d_d = tadd.getText();
		    acctype=tacctype.getText();
		    acc_em=tEmail.getText();
			 mob = Long.parseLong(tPhone.getText());
			 amt = Long.parseLong(tBalance.getText());
			
	//		 Deposit= Long.parseLong(tDep.getText());
			 
		 insertcustomer(acc_no,nm,d_o_b,n_a_t,gender1,a_d_d,acctype,acc_em,mob,amt);
		
		 
		 
		     taccno.setText("");
			 tName.setText("");
			 tdob.setText("");
			 tnat.setText("");
			 tadd.setText("");
			 tacctype.setText("");
			 tEmail.setText("");
			 tPhone.setText("");
			 tBalance.setText("");
			 
			 JOptionPane.showMessageDialog(null, "ACCOUNT CREATED",null,JOptionPane.PLAIN_MESSAGE );
			 			 						
		}
		else if(B.getActionCommand().equals("BACK")){
			this.frame.dispose();
			new private_section();
			
		}
		
	}
}

class AcHolder_detail extends register{
	
	
	AcHolder_detail(){
		
		this.frame.dispose();
		
		b1 =new JButton();
		JScrollPane jsp;
		JTable t;
		
		frame = new JFrame("Customer Details");
		p1 = new JPanel();
				
	   p1.setBounds(20, 100,1240,450);
	   p1.setLayout(null);		
	  p1.setBackground(Color.yellow);	
		
	   
	   
	   
		String colmn[] ={"S.No","Account No","Account Holder"," Date Of Birth "," Nationality ","Gender","Address","Account Type",
				"Email Id","Mobile no","Balance","Credit","Debit"};
		String data[][] = new String[30][13];
		
		
		
		
		
		int i=0;
		
		for(Customer c1 : CA)
		{	
			data[i][0] = Integer.toString(i+1);
			data[i][1] = Integer.toString(c1.getAccno());
			data[i][2] = c1.getAccnm();
			data[i][3] = c1.getDob();
			data[i][4] = c1.getNat();
			data[i][5] = c1.getGender();
			data[i][6] = c1.getAddress();
			data[i][7] = c1.getAcctype();
			data[i][8] = c1.getAccem();
			data[i][9] = Long.toString(c1.getMob());
			data[i][10] = Long.toString(c1.getAmt());
			
			data[i][11] = Long.toString(c1.getDeposit());
			data[i][12] = Long.toString(c1.getWidth());
			
			i++;	
		}
		
		t=new JTable(data,colmn);
		jsp=new JScrollPane(t); 
		p1.add(jsp);
		
		jsp.setBounds(0, 0, 1240, 375);
		
		
		b1.setBounds(40, 580, 150, 50);
		b1.setText("BACK");
		b1.setFocusable(false);
		b1.addActionListener(this);
		
		frame.setLayout(null);		
		frame.setSize(1400, 690);				
		frame.setVisible(true);
		frame.add(p1);
		frame.add(b1);
		frame.getContentPane().setBackground(Color.yellow);
	}
	public void actionPerformed(ActionEvent e) {
		
		JButton B = (JButton)e.getSource();
			
			
		 if(B.getActionCommand().equals("BACK")){
				this.frame.dispose();
				new private_section();
			}
	    
}
		
}	
	

	
	
